# project objectives:

- [x] Create audio player
- [x] Add/Animate Logo
- [ ] navigation - home, tour, merch, booking
- [ ] Add band photo as Hero Image
- [ ] Tour scheduling section
- [ ] merchandise section
- [ ] music video gallery
- [ ] footer section
