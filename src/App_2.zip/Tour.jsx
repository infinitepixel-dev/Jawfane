const Tour = () => {
  return (
    <section id="tour" className="h-screen bg-gray-800 text-white p-8">
      <h2 className="text-4xl mb-4">Tour Schedule</h2>
      {/* Add your tour schedule content here */}
    </section>
  );
};

export default Tour;
